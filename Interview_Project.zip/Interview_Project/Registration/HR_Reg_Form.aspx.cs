﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Net.Mail;

public partial class Registration_HR_Reg_Form : System.Web.UI.Page
{
    Reg_BAL BE = new Reg_BAL();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack == false)
        {
            ddl_country.Items.Insert(0, "Select");
            ddl_country.DataSource = CountryList();

            ddl_country.DataBind();
        }
    }
    public static List<string> CountryList()
    {
        //Creating list
        List<string> CultureList = new List<string>();

        //getting  the specific  CultureInfo from CultureInfo class
        CultureInfo[] getCultureInfo = CultureInfo.GetCultures(CultureTypes.SpecificCultures);

        foreach (CultureInfo getCulture in getCultureInfo)
        {
            //creating the object of RegionInfo class
            RegionInfo GetRegionInfo = new RegionInfo(getCulture.LCID);
            //adding each county Name into the arraylist
            if (!(CultureList.Contains(GetRegionInfo.EnglishName)))
            {
                CultureList.Add(GetRegionInfo.EnglishName);
            }
        }
        //sorting array by using sort method to get countries in order
        CultureList.Sort();
        //returning country list
        return CultureList;
    }
    public void setvalue()
    {
        if (txt_fnm.Text != "") { BE.Fnm = txt_fnm.Text; } else { BE.Fnm = ""; }
        if (txt_lnm.Text != "") { BE.Lnm = txt_lnm.Text; } else { BE.Lnm = ""; }
        if (txt_contact.Text != "") { BE.Contact = txt_contact.Text; } else { BE.Contact = ""; }
        if (txt_email.Text != "") { BE.Email = txt_email.Text; } else { BE.Email = ""; }
        if (txt_city.Text != "") { BE.City = txt_city.Text; } else { BE.City = ""; }
        if (txt_state.Text != "") { BE.State = txt_state.Text; } else { BE.State = ""; }
        if (ddl_country.SelectedValue != "") { BE.Country = ddl_country.SelectedItem.Text; } else { BE.Country = ""; }
        if (txt_pin.Text != "") { BE.Pincode = txt_pin.Text; } else { BE.Pincode = "0"; }
        if (Img_pic.ImageUrl != "") { BE.ImgPath1 = Img_pic.ImageUrl; } else { BE.ImgPath1 = ""; }
        BE.Reg_id = "0";

    }

    protected void btn_save_Click(object sender, EventArgs e)
    {
        setvalue();
        BE.Flag1 = "Save";
        if (BE.save_data() == true)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "str", "<script language='javascript'>alert('Registratered Successfully.Confirmation link to set password send on your email ID. !');</script>", false);
            sendemail();
        }
        else
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "str", "<script language='javascript'>alert('Not Registratered Successfully. !');</script>", false);
        }
    }
    protected void UpFile_Click(object sender, EventArgs e)
    {
        if (Upload_Pic.HasFile == true)
        {
            Upload_Pic.SaveAs(Server.MapPath("~/Admin_Photo/") + Upload_Pic.FileName);
            //txt_flnm.Text = fil.FileName;
            Img_pic.ImageUrl = "~/Admin_Photo/" + Upload_Pic.FileName;
        }
        BE.ImgPath1 = "~/Admin_Photo/" + Upload_Pic.FileName;
    }
    public void sendemail()
    {
        try
        {

            string str = "WelCome : " + " " + txt_fnm.Text + "\n" + "Please Click on below link to confirm your account and set password :" + " " + "http://localhost:49317/Interview_Project/Registration/SetPassword.aspx?usercrd=" + txt_email.Text + "";

            MailMessage mail = new MailMessage();
            SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

            mail.From = new MailAddress("swapnajapatunkar@gmail.com");
            mail.To.Add(txt_email.Text);
            mail.Subject = "Registration From user" + txt_fnm.Text;
            mail.Body = str.ToString();

            SmtpServer.UseDefaultCredentials = false;
            SmtpServer.Port = 587;
            
            SmtpServer.Credentials = new System.Net.NetworkCredential("swapnajapatunkar@gmail.com", "abcd");
            SmtpServer.EnableSsl = true;
            
            SmtpServer.Send(mail);


        }
        catch
        {
           ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "str", "<script language='javascript'>alert('Please Check Internet Connection and Try Again..');</script>", false);
        }
    
    }
}