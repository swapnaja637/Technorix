﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Registration_SetPassword : System.Web.UI.Page
{
   // string email = "";
    Reg_BAL BE = new Reg_BAL();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack == false)
        {
            if (Request.QueryString["usercrd"] != "" && Request.QueryString["usercrd"] != null)
            {
                Session["email"] = Request.QueryString["usercrd"].ToString();
            }
            else
            {
                Session["email"] = "";
            }
        }
    }
    public void setvalue()
    {
        

    }
    protected void btn_save_Click(object sender, EventArgs e)
    {
        string pass = BE.get_pass(txt_email.Text);
        if (txt_pass.Text == pass)
        {
            Session["unm"] = BE.Fnm;
            Session["img"] = BE.ImgPath1;
            Response.Redirect("~/Registration/Index.aspx");
            
           
        }
        else
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "str", "<script language='javascript'>alert('Wrong Password..');</script>", false);
        }
    }
}