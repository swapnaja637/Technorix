﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Registration_Index : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack == false)
        {
            if (Session["unm"] != null && Session["unm"] != "")
            {
                lbl_nm.Text = "WelCome" + " " + Session["unm"].ToString();
            }
            else
            {
                Response.Redirect("~/Registration/LoginPage.aspx");
            }
            if (Session["img"] != null && Session["img"] != "")
            {
                img_profile.ImageUrl = Session["img"].ToString();
            }
        }
    }
    protected void btn_AddEmp_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Employee_Reg/EmpReg_Form.aspx");
    }
}