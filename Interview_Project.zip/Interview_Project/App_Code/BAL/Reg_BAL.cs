﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Reg_BAL
/// </summary>
public class Reg_BAL
{
    DAL_Reg DE = new DAL_Reg();
    string reg_id, fnm, lnm, email, contact, city, state, country, pincode, Flag, ImgPath, frmdt, todt, totexp, Employernm;

    public string Employernm1
    {
        get { return Employernm; }
        set { Employernm = value; }
    }

    public string Totexp
    {
        get { return totexp; }
        set { totexp = value; }
    }

    public string Todt
    {
        get { return todt; }
        set { todt = value; }
    }

    public string Frmdt
    {
        get { return frmdt; }
        set { frmdt = value; }
    }

    public string ImgPath1
    {
        get { return ImgPath; }
        set { ImgPath = value; }
    }

    public string Flag1
    {
        get { return Flag; }
        set { Flag = value; }
    }

    public string Pincode
    {
        get { return pincode; }
        set { pincode = value; }
    }

    public string Country
    {
        get { return country; }
        set { country = value; }
    }

    public string State
    {
        get { return state; }
        set { state = value; }
    }

    public string City
    {
        get { return city; }
        set { city = value; }
    }

    public string Contact
    {
        get { return contact; }
        set { contact = value; }
    }

    public string Email
    {
        get { return email; }
        set { email = value; }
    }

    public string Lnm
    {
        get { return lnm; }
        set { lnm = value; }
    }

    public string Fnm
    {
        get { return fnm; }
        set { fnm = value; }
    }

    public string Reg_id
    {
        get { return reg_id; }
        set { reg_id = value; }
    }
	public Reg_BAL()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public bool save_data()
    {
        bool status;
        status = DE.save_HRReg(this);
        return status;
    }
    public bool save_password(string email, string str)
    {
        bool status;
        status = DE.save_Password(email,str);
        return status;
    }
    public string get_pass(string email)
    {
        string pass = "";
        pass = DE.getpass(email,this);
        return pass;
    }
    public bool save_empreg()
    {
        bool status;
        status = DE.save_EmpReg(this);
        return status;
    }
}