﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
/// <summary>
/// Summary description for DBCon
/// </summary>
public class DBCon
{
    SqlConnection con=new SqlConnection();
    SqlCommand cmd;
    SqlTransaction trans;
    SqlDataAdapter ad=new SqlDataAdapter();
   public SqlDataReader dr;
	public DBCon()
	{
		con.ConnectionString="Data Source='TITIKSHA-PC';Initial Catalog='SwapnajaP';Integrated Security='True'";

	}
    public bool CRUD_Ops(string str)
    {
        bool status = true;
        try
        {
             if (con.State == ConnectionState.Closed)
            {
                con.Open();
                trans = con.BeginTransaction();
            }
            cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.Transaction = trans;
            cmd.CommandText = str;
            cmd.ExecuteNonQuery();
            trans.Commit();
            con.Close();
            status = true;
        }
        catch
        {
            trans.Rollback();
            con.Close();
            status = false;
        }
        //finally
        //{
        //    con.Close();
        //}
        return status;
    }
    public SqlDataReader get_value(string str)
    {
        string pass="";
        try
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
                trans = con.BeginTransaction();
            }
            cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.Transaction = trans;
            cmd.CommandText = str;
            dr = cmd.ExecuteReader();
        }
        catch
        {
        }
        return dr;
    }
}