﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DAL_Reg
/// </summary>
public class DAL_Reg
{
    DBCon com = new DBCon();
	public DAL_Reg()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public bool save_HRReg(Reg_BAL BE)
    {
        bool status;
        status=com.CRUD_Ops("exec RegistrationTab_CRUD_Sp "+BE.Reg_id+",'"+BE.Fnm+"','"+BE.Lnm+"','"+BE.Email+"','"+BE.Contact+"','"+BE.City+"','"+BE.State+"','"+BE.Country+"',"+BE.Pincode+",'"+BE.ImgPath1+"','-','"+BE.Flag1+"'");
        return status;
    }
    public bool save_Password(string email,string pass)
    {
        bool status;
        status = com.CRUD_Ops("exec Save_Pass_sp'" + email + "','"+pass+"'");
        return status;
    }
    public string getpass(string email,Reg_BAL BE)
    {
        string pass = "", nm = "", img_path = ""; ;

        com.get_value("Select user_pass,nm,imgpath from View_For_Reg where Email='" + email + "'");
        
        if (com.dr.Read())
        {
            pass = com.dr[0].ToString();
            BE.Fnm = com.dr[1].ToString();
            BE.ImgPath1= com.dr[2].ToString();
        }
        com.dr.Close();
        return pass;
    
    }
    public bool save_EmpReg(Reg_BAL BE)
    {
        bool status;
        status = com.CRUD_Ops("exec EmpRegistrationTab_CRUD_Sp '" + BE.Fnm + "','" + BE.Lnm + "','" + BE.Email + "','" + BE.Contact + "','" + BE.City + "','" + BE.State + "','" + BE.Country + "'," + BE.Pincode + ",'" + BE.ImgPath1 + "','" + BE.Frmdt + "','" + BE.Todt + "'," + BE.Totexp + ",'" + BE.Employernm1 + "'");
        return status;
    }
}